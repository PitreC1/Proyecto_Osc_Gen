
package test;

import javax.swing.JFrame;
import vista.vistaOsciloscopio;

public class Test {

    public static void main(String[] args) {
        
        vistaOsciloscopio objVistaOsciloscopio = new vistaOsciloscopio();
        objVistaOsciloscopio.setVisible(true);
        
    }
    
}
