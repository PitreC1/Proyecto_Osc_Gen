package vista;

import com.panamahitek.ArduinoException;
import com.panamahitek.PanamaHitek_Arduino;
import java.text.DecimalFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JLabel;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;
import jssc.SerialPortException;

public class vistaOsciloscopio extends javax.swing.JFrame {

    private PanamaHitek_Arduino ino = new PanamaHitek_Arduino();
    
        public SerialPortEventListener listener = new SerialPortEventListener() {

        @Override
        //Si se recibe algun dato en el puerto serie, se ejecuta el siguiente metodo
        public void serialEvent(SerialPortEvent serialPortEvent) {
            LeerDatos();
        }
    };

    public vistaOsciloscopio() {
        initComponents();
        inicializarConexion();
        this.setLocationRelativeTo(null);

    }

    public void inicializarConexion() {

        try {
            //Se inicializa la conexion con el Arduino en el puerto COM5
            ino.arduinoRXTX("COM7", 9600, listener);

        } catch (ArduinoException ex) {
            Logger.getLogger(vistaOsciloscopio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void LeerDatos() {
        try {
            /*
                Los datos en el puerto serie se envian caracter por caracter. Si se
                desea esperar a terminar de recibir el mensaje antes de imprimirlo, 
                el metodo isMessageAvailable() devolvera TRUE cuando se haya terminado
                de recibir el mensaje, el cual podra ser impreso a traves del metodo
                printMessage()
             */

            if (ino.isMessageAvailable()) {
                //Se le asigna el mensaje recibido a la variable valorAnalogico 
                String valorAnalogico = ino.printMessage();
                //Se imprime la variable valorAnalogico
                System.out.println("Mensaje recibido --> " + valorAnalogico);
                float voltajePP = (Float.parseFloat(valorAnalogico) * 5) / 1024;
                DecimalFormat formato1 = new DecimalFormat("#.##");

                this.jLabelValorVppCH1.setText("" + formato1.format(voltajePP) + " V");

                float voltajeVp = voltajePP / 2;
                this.jLabelValorVpCH1.setText("" + formato1.format(voltajeVp) + " V");

                float voltajeVrms = (float) (voltajePP / (Math.sqrt(2)));
                this.jLabelValorVrmsCH1.setText("" + formato1.format(voltajeVrms) + " V");
                //interrupcion();
            }
        } catch (SerialPortException ex) {
            Logger.getLogger(vistaOsciloscopio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ArduinoException ex) {
            Logger.getLogger(vistaOsciloscopio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroupOpciones = new javax.swing.ButtonGroup();
        jPanelChanel = new javax.swing.JPanel();
        jPanelChanel1 = new javax.swing.JPanel();
        jLabelCH1 = new javax.swing.JLabel();
        jLabelVrmsCH1 = new javax.swing.JLabel();
        jLabelVppCH1 = new javax.swing.JLabel();
        jLabelVpCH1 = new javax.swing.JLabel();
        jLabelValorVppCH1 = new javax.swing.JLabel();
        jLabelValorVpCH1 = new javax.swing.JLabel();
        jLabelValorVrmsCH1 = new javax.swing.JLabel();
        jLabelValorVrmsCH2 = new javax.swing.JLabel();
        jPanelOpciones = new javax.swing.JPanel();
        jToggleButtonRun = new javax.swing.JToggleButton();
        jToggleButtonStop = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setFocusable(false);
        setResizable(false);

        jPanelChanel.setBackground(new java.awt.Color(0, 0, 0));

        jPanelChanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanelChanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 204, 0)));

        jLabelCH1.setFont(new java.awt.Font("Bookman Old Style", 1, 18)); // NOI18N
        jLabelCH1.setForeground(new java.awt.Color(255, 204, 51));
        jLabelCH1.setText("CH");

        jLabelVrmsCH1.setFont(new java.awt.Font("Bookman Old Style", 1, 18)); // NOI18N
        jLabelVrmsCH1.setForeground(new java.awt.Color(255, 204, 51));
        jLabelVrmsCH1.setText("Vrms:");

        jLabelVppCH1.setFont(new java.awt.Font("Bookman Old Style", 1, 18)); // NOI18N
        jLabelVppCH1.setForeground(new java.awt.Color(255, 204, 51));
        jLabelVppCH1.setText("Vpp:");

        jLabelVpCH1.setFont(new java.awt.Font("Bookman Old Style", 1, 18)); // NOI18N
        jLabelVpCH1.setForeground(new java.awt.Color(255, 204, 51));
        jLabelVpCH1.setText("Vp:");

        jLabelValorVppCH1.setForeground(new java.awt.Color(255, 204, 51));

        jLabelValorVpCH1.setForeground(new java.awt.Color(255, 204, 51));

        jLabelValorVrmsCH1.setForeground(new java.awt.Color(255, 204, 51));

        jLabelValorVrmsCH2.setForeground(new java.awt.Color(255, 204, 51));

        javax.swing.GroupLayout jPanelChanel1Layout = new javax.swing.GroupLayout(jPanelChanel1);
        jPanelChanel1.setLayout(jPanelChanel1Layout);
        jPanelChanel1Layout.setHorizontalGroup(
            jPanelChanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelChanel1Layout.createSequentialGroup()
                .addGroup(jPanelChanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanelChanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanelChanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelChanel1Layout.createSequentialGroup()
                                .addGroup(jPanelChanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelVrmsCH1)
                                    .addComponent(jLabelVpCH1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanelChanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelValorVpCH1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabelValorVrmsCH1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanelChanel1Layout.createSequentialGroup()
                                .addGroup(jPanelChanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelChanel1Layout.createSequentialGroup()
                                        .addGap(52, 52, 52)
                                        .addComponent(jLabelValorVrmsCH2, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanelChanel1Layout.createSequentialGroup()
                                        .addComponent(jLabelVppCH1)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabelValorVppCH1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 2, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanelChanel1Layout.createSequentialGroup()
                        .addGap(106, 106, 106)
                        .addComponent(jLabelCH1)))
                .addContainerGap(117, Short.MAX_VALUE))
        );
        jPanelChanel1Layout.setVerticalGroup(
            jPanelChanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelChanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelCH1)
                .addGap(31, 31, 31)
                .addGroup(jPanelChanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelVppCH1)
                    .addComponent(jLabelValorVppCH1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanelChanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelVpCH1)
                    .addComponent(jLabelValorVpCH1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanelChanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelValorVrmsCH1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelVrmsCH1))
                .addGap(18, 18, Short.MAX_VALUE)
                .addComponent(jLabelValorVrmsCH2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );

        javax.swing.GroupLayout jPanelChanelLayout = new javax.swing.GroupLayout(jPanelChanel);
        jPanelChanel.setLayout(jPanelChanelLayout);
        jPanelChanelLayout.setHorizontalGroup(
            jPanelChanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelChanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanelChanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanelChanelLayout.setVerticalGroup(
            jPanelChanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelChanelLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jPanelChanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        jPanelOpciones.setBackground(new java.awt.Color(153, 153, 153));
        jPanelOpciones.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jToggleButtonRun.setBackground(new java.awt.Color(153, 255, 51));
        buttonGroupOpciones.add(jToggleButtonRun);
        jToggleButtonRun.setFont(new java.awt.Font("Bookman Old Style", 1, 18)); // NOI18N
        jToggleButtonRun.setText("Run");
        jToggleButtonRun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButtonRunActionPerformed(evt);
            }
        });

        jToggleButtonStop.setBackground(new java.awt.Color(255, 102, 102));
        buttonGroupOpciones.add(jToggleButtonStop);
        jToggleButtonStop.setFont(new java.awt.Font("Bookman Old Style", 1, 18)); // NOI18N
        jToggleButtonStop.setText("Stop");
        jToggleButtonStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButtonStopActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelOpcionesLayout = new javax.swing.GroupLayout(jPanelOpciones);
        jPanelOpciones.setLayout(jPanelOpcionesLayout);
        jPanelOpcionesLayout.setHorizontalGroup(
            jPanelOpcionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelOpcionesLayout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addGroup(jPanelOpcionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jToggleButtonStop, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jToggleButtonRun, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(17, 17, 17))
        );
        jPanelOpcionesLayout.setVerticalGroup(
            jPanelOpcionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelOpcionesLayout.createSequentialGroup()
                .addGap(92, 92, 92)
                .addComponent(jToggleButtonRun)
                .addGap(18, 18, 18)
                .addComponent(jToggleButtonStop)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanelChanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanelOpciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanelChanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanelOpciones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jToggleButtonRunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButtonRunActionPerformed

        //if (this.jToggleButtonRun.isSelected() == false) {
            try {
                // TODO add your handling code here:
                ino.sendData("0");

            } catch (Exception ex) {
                Logger.getLogger(vistaOsciloscopio.class.getName()).log(Level.SEVERE, null, ex);
            }
        //}
    }//GEN-LAST:event_jToggleButtonRunActionPerformed

    private void jToggleButtonStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButtonStopActionPerformed

            try {
                // TODO add your handling code here:
                ino.sendData("1");
                
            } catch (Exception ex) {
                Logger.getLogger(vistaOsciloscopio.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_jToggleButtonStopActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroupOpciones;
    private javax.swing.JLabel jLabelCH1;
    private javax.swing.JLabel jLabelValorVpCH1;
    private javax.swing.JLabel jLabelValorVppCH1;
    private javax.swing.JLabel jLabelValorVrmsCH1;
    private javax.swing.JLabel jLabelValorVrmsCH2;
    private javax.swing.JLabel jLabelVpCH1;
    private javax.swing.JLabel jLabelVppCH1;
    private javax.swing.JLabel jLabelVrmsCH1;
    private javax.swing.JPanel jPanelChanel;
    private javax.swing.JPanel jPanelChanel1;
    private javax.swing.JPanel jPanelOpciones;
    private javax.swing.JToggleButton jToggleButtonRun;
    private javax.swing.JToggleButton jToggleButtonStop;
    // End of variables declaration//GEN-END:variables
}
