/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import com.panamahitek.PanamaHitek_Arduino;
import java.util.logging.Level;
import java.util.logging.Logger;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;
import jssc.SerialPortException;
import com.panamahitek.ArduinoException;
import java.awt.Image;
import javax.swing.ImageIcon;


public class interrupcion extends javax.swing.JFrame {
    
    PanamaHitek_Arduino ino = new PanamaHitek_Arduino();
    
    public interrupcion() {
        try {
            ino.arduinoRXTX("COM4", 9600, listener);
        } catch (ArduinoException ex) {
            Logger.getLogger(interrupcion.class.getName()).log(Level.SEVERE, null, ex);
        }
        initComponents();
        establecerIconos();
        this.setLocationRelativeTo(null);
    }
    private void establecerIconos()
    {
        //Logo usario
        Image img1= new ImageIcon(getClass().getResource("/recursos/sine.png")).getImage();
        ImageIcon img2=new ImageIcon(img1.getScaledInstance(100, 60, Image.SCALE_SMOOTH));
        this.jLabelsin.setIcon(img2);
        //Logo contraseña
        Image img3= new ImageIcon(getClass().getResource("/recursos/Square.png")).getImage();
        ImageIcon img4=new ImageIcon(img3.getScaledInstance(100, 60, Image.SCALE_SMOOTH));
        this.jLabelrect.setIcon(img4);
        //Logo menú
        Image img5= new ImageIcon(getClass().getResource("/recursos/triangle.png")).getImage();
        ImageIcon img6=new ImageIcon(img5.getScaledInstance(100, 60, Image.SCALE_SMOOTH));
        this.jLabeltrgl.setIcon(img6);
    }
    SerialPortEventListener listener = new SerialPortEventListener() {
        @Override
        public void serialEvent(SerialPortEvent spe) {
            try {
                if(ino.isMessageAvailable()){
                    String msg = ino.printMessage();
                    //System.out.println("Lectura---> "+msg);
                }
            } catch (SerialPortException ex) {
                Logger.getLogger(interrupcion.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ArduinoException ex) {
                Logger.getLogger(interrupcion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    };

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButton1 = new javax.swing.JRadioButton();
        jPanel1 = new javax.swing.JPanel();
        jButtonOn = new javax.swing.JButton();
        jButtonOFF = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jButtonSen = new javax.swing.JButton();
        jButtonRecto = new javax.swing.JButton();
        jButtonTriangl = new javax.swing.JButton();
        jLabelsin = new javax.swing.JLabel();
        jLabelrect = new javax.swing.JLabel();
        jLabeltrgl = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jSliderAmp = new javax.swing.JSlider();

        jRadioButton1.setText("jRadioButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 153));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jButtonOn.setBackground(new java.awt.Color(102, 255, 102));
        jButtonOn.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        jButtonOn.setText("ON");
        jButtonOn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonOnActionPerformed(evt);
            }
        });

        jButtonOFF.setBackground(new java.awt.Color(255, 51, 51));
        jButtonOFF.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        jButtonOFF.setForeground(new java.awt.Color(255, 255, 255));
        jButtonOFF.setText("OFF");
        jButtonOFF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonOFFActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButtonOFF, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonOn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(59, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addComponent(jButtonOn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonOFF)
                .addGap(19, 19, 19))
        );

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jButtonSen.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        jButtonSen.setText("Sinusoidal");
        jButtonSen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSenActionPerformed(evt);
            }
        });

        jButtonRecto.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        jButtonRecto.setText("Rectangular");
        jButtonRecto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRectoActionPerformed(evt);
            }
        });

        jButtonTriangl.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        jButtonTriangl.setText("Triangular");
        jButtonTriangl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonTrianglActionPerformed(evt);
            }
        });

        jLabelsin.setBackground(new java.awt.Color(153, 153, 153));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jButtonSen, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabelsin, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonRecto)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabelrect, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jButtonTriangl)
                        .addGap(43, 43, 43))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabeltrgl, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelsin, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
                    .addComponent(jLabelrect, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabeltrgl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonSen)
                    .addComponent(jButtonRecto)
                    .addComponent(jButtonTriangl))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLabel1.setFont(new java.awt.Font("Bookman Old Style", 1, 18)); // NOI18N
        jLabel1.setText("Voltaje");

        jSliderAmp.setBackground(new java.awt.Color(204, 204, 204));
        jSliderAmp.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        jSliderAmp.setForeground(new java.awt.Color(0, 0, 0));
        jSliderAmp.setMajorTickSpacing(1);
        jSliderAmp.setMaximum(5);
        jSliderAmp.setMinimum(1);
        jSliderAmp.setMinorTickSpacing(1);
        jSliderAmp.setPaintLabels(true);
        jSliderAmp.setPaintTicks(true);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(125, 125, 125))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jSliderAmp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSliderAmp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonTrianglActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTrianglActionPerformed
        try {
            ino.sendData("t");
        } catch (ArduinoException ex) {
            Logger.getLogger(interrupcion.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SerialPortException ex) {
            Logger.getLogger(interrupcion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButtonTrianglActionPerformed

    private void jButtonSenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSenActionPerformed
        try {
            ino.sendData("s");
            
        } catch (ArduinoException ex) {
            Logger.getLogger(interrupcion.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SerialPortException ex) {
            Logger.getLogger(interrupcion.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButtonSenActionPerformed

    private void jButtonRectoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRectoActionPerformed
       try {
            ino.sendData("r");
            
        } catch (ArduinoException ex) {
            Logger.getLogger(interrupcion.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SerialPortException ex) {
            Logger.getLogger(interrupcion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButtonRectoActionPerformed

    private void jButtonOnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonOnActionPerformed
        try {
            if(jSliderAmp.getValue()==1){
            ino.sendData("a");
            }
            if(jSliderAmp.getValue()==2){
                ino.sendData("b");
            }
            if(jSliderAmp.getValue()==3){
                ino.sendData("c");
            }
            if(jSliderAmp.getValue()==4){
                ino.sendData("d");
            }
            if(jSliderAmp.getValue()==5){
                ino.sendData("e");
            }
        } catch (ArduinoException ex) {
            Logger.getLogger(interrupcion.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SerialPortException ex) {
            Logger.getLogger(interrupcion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButtonOnActionPerformed

    private void jButtonOFFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonOFFActionPerformed
        try {
            ino.sendData("o");
        } catch (ArduinoException ex) {
            Logger.getLogger(interrupcion.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SerialPortException ex) {
            Logger.getLogger(interrupcion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButtonOFFActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonOFF;
    private javax.swing.JButton jButtonOn;
    private javax.swing.JButton jButtonRecto;
    private javax.swing.JButton jButtonSen;
    private javax.swing.JButton jButtonTriangl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelrect;
    private javax.swing.JLabel jLabelsin;
    private javax.swing.JLabel jLabeltrgl;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JSlider jSliderAmp;
    // End of variables declaration//GEN-END:variables
}
