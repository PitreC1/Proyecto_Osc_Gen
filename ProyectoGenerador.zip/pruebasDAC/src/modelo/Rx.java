package modelo;
import com.panamahitek.ArduinoException;
import com.panamahitek.PanamaHitek_Arduino;
import java.util.logging.Level;
import java.util.logging.Logger;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;
import jssc.SerialPortException;
import modelo.interrupcion;

public class Rx {
    
//    static PanamaHitek_Arduino ino = new PanamaHitek_Arduino();
//    
//    static SerialPortEventListener listener = new SerialPortEventListener() {
//        @Override
//        public void serialEvent(SerialPortEvent spe) {
//            try {
//                if(ino.isMessageAvailable()){
//                    String msg = ino.printMessage();
//                    System.out.println("Lectura---> "+msg);
//                }
//            } catch (SerialPortException ex) {
//                Logger.getLogger(Rx.class.getName()).log(Level.SEVERE, null, ex);
//            } catch (ArduinoException ex) {
//                Logger.getLogger(Rx.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }
//    };
    public static void main(String[] args) {
//        try {
//            ino.arduinoRX("COM4", 9600, listener);
//        } catch (ArduinoException ex) {
//            Logger.getLogger(Rx.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (SerialPortException ex) {
//            Logger.getLogger(Rx.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
        interrupcion prueba = new interrupcion();
        prueba.setVisible(true);

    }
}
